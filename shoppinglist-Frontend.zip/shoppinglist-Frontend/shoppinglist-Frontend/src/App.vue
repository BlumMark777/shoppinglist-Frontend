<script setup>
import TobuyList from './components/TobuyList.vue'
</script>

<template>
  <main>
    <h1>🛒 Meine Einkaufsliste</h1>
    <TobuyList />
  </main>
</template>

<style>
main {
  max-width: 640px;
  margin: 2rem auto;
  font-family: system-ui, sans-serif;
  text-align: center;
}
</style>

